-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2017 at 02:55 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kelompok2`
--

-- --------------------------------------------------------

--
-- Table structure for table `guru`
--

CREATE TABLE IF NOT EXISTS `guru` (
`nip` int(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `bidang_studi` varchar(30) NOT NULL,
  `gaji` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15650076 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guru`
--

INSERT INTO `guru` (`nip`, `nama`, `bidang_studi`, `gaji`) VALUES
(15650051, 'Soleram', 'Qurdits', 2000),
(15650052, 'Lutpi', 'Matematika', 2000),
(15650053, 'Mujur', 'Kimia', 2500),
(15650054, 'Cion', 'Biologi', 2500),
(15650055, 'Nidia', 'Komputer', 2000),
(15650056, 'Malin', 'Akidah', 2500),
(15650057, 'Sujiwo', 'Bahasa Daerah', 3000),
(15650058, 'Ananda', 'Otomotif', 3000),
(15650059, 'Kevin', 'BahasaIndonesia', 2000),
(15650060, 'Boy', 'Matematika', 3000),
(15650061, 'Bukini', 'Fiqih', 2500),
(15650062, 'Bumi', 'Aqidah', 2500),
(15650063, 'Yuli', 'Kimia', 3000),
(15650064, 'Romadhon', 'Kimia', 3500),
(15650065, 'Mariani', 'Fiqih', 2500),
(15650066, 'Him', 'Bahasa Inggris', 3000),
(15650067, 'Ridho', 'Matematika', 3500),
(15650068, 'Imam', 'Biologi', 3500),
(15650069, 'Abdur', 'SKI', 2500),
(15650070, 'Marsiati', 'Seni Budaya', 3000),
(15650071, 'Bambang', 'TIK', 3500),
(15650072, 'Agus', 'TIK', 3000),
(15650073, 'Basuki', 'Matematika', 4000),
(15650074, 'Is', 'Bahasa Inggris', 3500),
(15650075, 'Ed', 'Fisika', 3000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guru`
--
ALTER TABLE `guru`
 ADD PRIMARY KEY (`nip`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `guru`
--
ALTER TABLE `guru`
MODIFY `nip` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15650076;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
